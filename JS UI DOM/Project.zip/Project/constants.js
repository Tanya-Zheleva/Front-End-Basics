'use strict'

let utilities = {
    width: 1000
};

class Utils {
    get width() {
        return 1000;
    }
}

// module.exports = utilities;
//module.exports = utilities;

export function test() {
    console.log(7);
}